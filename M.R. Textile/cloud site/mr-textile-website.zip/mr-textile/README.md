# M.R. Textile / M.R. Sarees — Marketing Website

A static, framework-free marketing site (HTML5 + CSS3 + vanilla ES6+ JS) for
M.R. Textile, a saree wholesaler in Surat, Gujarat. This is a **branding and
lead-generation site**, not a storefront — there is no cart, checkout, or
pricing anywhere on it, by design.

## Before you publish — please read

This project was built without any product photography (no images were
provided when the site was generated). Every image you see —
hero backgrounds, the 10 collection cards, the 12 gallery close-ups, and the
About/lifestyle photo — is an **elegant placeholder graphic**, not a real
photo. They're organized so real photography drops in with zero layout
changes. See "Replacing placeholder imagery" below.

Three other things are placeholder/illustrative and should be reviewed before
launch:

1. **About-section stats** (`index.html`, `#about`): "1000+ Design
   Varieties" and "500+ Wholesale Partners" are illustrative sample figures.
   "10+ Saree Categories" and "6 Days Open Weekly" are accurate, drawn from
   the site's own content and the business hours you provided. Look for the
   `NOTE FOR MAINTAINER` HTML comment just above the stat markup.
2. **Testimonials** (`#testimonials`) are sample/placeholder reviews written
   to be easy to swap for real retailer feedback — they are not quotes from
   real people.
3. **The contact form does not send anywhere yet.** It's a static site with
   no backend, so `js/contact-form.js` currently validates the form and
   shows a success state, but the inquiry itself goes nowhere. See the `TODO`
   comment at the top of that file — wire it to your own backend endpoint or
   a form-backend service (Formspree, EmailJS, etc.) before relying on it.

Also update the placeholder domain (`https://www.mrtextile.example/`) used
in the canonical tag, Open Graph tags, Twitter Card tags, `robots.txt` and
`sitemap.xml` once you have a real domain.

## Folder structure

```
mr-textile/
├── index.html
├── robots.txt
├── sitemap.xml
├── site.webmanifest
├── favicon.ico
├── css/
│   ├── main.css          ← production bundle (linked from index.html)
│   └── source/           ← edit these; main.css is generated from them
│       ├── variables.css      (design tokens: color, type, spacing, motion)
│       ├── base.css           (reset, base element styles, a11y)
│       ├── utilities.css      (containers, buttons, eyebrow labels, the
│       │                       zari-divider signature element)
│       ├── layout.css         (preloader, nav, hero, footer)
│       ├── components.css     (about, why-choose-us)
│       ├── collections.css    (collection cards + filters)
│       ├── gallery.css        (masonry grid + shared lightbox)
│       ├── testimonials-faq.css
│       ├── contact.css        (contact cards, form, map)
│       ├── floating-ui.css    (WhatsApp button, back-to-top, toasts)
│       ├── animations.css     (keyframes, scroll-reveal system)
│       └── responsive.css     (mobile/tablet/laptop/desktop breakpoints)
├── js/                   ← ES modules, one feature per file, wired in main.js
│   ├── main.js                (entry point — imports + initializes everything)
│   ├── preloader.js
│   ├── navigation.js
│   ├── hero-slider.js
│   ├── scroll-reveal.js
│   ├── counters.js
│   ├── lightbox.js             (shared by gallery + collections)
│   ├── gallery.js
│   ├── collections.js
│   ├── faq.js
│   ├── testimonials.js
│   ├── contact-form.js
│   ├── scroll-progress.js
│   ├── back-to-top.js
│   ├── lazy-images.js
│   └── toast.js
├── images/
│   ├── hero/              4 landscape background scenes (1920×1080)
│   ├── collections/       10 portrait cards, one per category (900×1200)
│   ├── gallery/           12 mixed-aspect close-ups for the masonry grid
│   └── lifestyle/         3 landscape scenes for About / accent use
└── icons/
    ├── favicon.ico, icon-*.png    (generated app icons)
    └── zari-pattern[-light].svg  (the repeating border-motif tile)
```

## Editing the CSS

Edit files under `css/source/`, **not** `css/main.css` directly — `main.css`
is a generated concatenation of the source files (shipped as one file so the
browser makes a single stylesheet request instead of chaining `@import`s,
which is slower). After editing a source file, regenerate the bundle:

```bash
cd css
{
  for f in variables base utilities layout components collections gallery \
           testimonials-faq contact floating-ui animations responsive; do
    cat "source/${f}.css"; echo
  done
} > main.css
```

## Running locally

The JavaScript uses native ES modules (`<script type="module">`), which
browsers refuse to load over `file://` for security reasons. Serve the
folder with any static file server, for example:

```bash
cd mr-textile
python3 -m http.server 8080
# then open http://localhost:8080
```

## Replacing placeholder imagery

Drop in real photography using the same filenames (or update the `src`
attributes in `index.html` to match new filenames) and the same aspect
ratios so nothing in the layout shifts:

| Folder                | Used for            | Recommended shape        |
|------------------------|---------------------|---------------------------|
| `images/hero/`         | Hero background slideshow | Landscape, 1920×1080 |
| `images/collections/`  | The 10 category cards | Portrait, ~3:4 |
| `images/gallery/`      | Masonry close-ups   | Mixed — keep a variety of portrait/landscape/square |
| `images/lifestyle/`    | About section photo | Landscape, ~4:5 crop applied via CSS |

Use real JPG/WEBP photography at these sizes (WEBP preferred for file size);
`loading="lazy"` is already set on every non-hero image.

## Content you'll likely want to personalize

- **FAQ answers** (`#faq`) are intentionally general (no invented MOQ figures,
  payment terms, etc.) — update with your actual policies.
- **Collection card "design count" labels** (e.g. "120+ Designs") are
  illustrative — update per real stock levels, or remove the label.
- **Social links** in the footer point to `#` placeholders except WhatsApp
  (which is wired to your provided number) — add real profile URLs or
  remove the icons that don't apply.

## Accessibility & performance notes

- Every interactive element is reachable and operable by keyboard; focus
  states are visible throughout (`:focus-visible`).
- All motion respects `prefers-reduced-motion`.
- Images are lazy-loaded (except the 4 hero slides, which are the LCP
  candidate and load eagerly by design).
- The gallery only ships 8 images eagerly; the remaining 4 reveal on
  "Load more" to keep initial payload smaller.
- Structured data (Schema.org `ClothingStore`), Open Graph, and Twitter Card
  metadata are all in `<head>` — update the placeholder domain before going
  live.
